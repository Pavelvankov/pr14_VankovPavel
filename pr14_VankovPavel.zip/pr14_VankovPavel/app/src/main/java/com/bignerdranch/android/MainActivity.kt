package com.bignerdranch.android.pr14_vankovpavel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAlarm = findViewById<ImageButton>(R.id.btnAlarm)
        val btnCalendar = findViewById<ImageButton>(R.id.btnCalendar)
        val btnSettings = findViewById<ImageButton>(R.id.btnSettings)
        val btnList = findViewById<ImageButton>(R.id.btnList)

        btnAlarm.setOnClickListener {
            val intent = Intent(this, AlarmActivity::class.java)
            startActivity(intent)
        }

        btnCalendar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // btnSettings doesn't do anything as per your requirement

        btnList.setOnClickListener {
            val intent = Intent(this, GeneralActivity::class.java)
            startActivity(intent)
        }
    }
}
