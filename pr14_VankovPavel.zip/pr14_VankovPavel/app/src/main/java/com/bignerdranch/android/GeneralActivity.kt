package com.bignerdranch.android.pr14_vankovpavel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Button

class GeneralActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_general)

        val btnAlarm = findViewById<ImageButton>(R.id.btnAlarm)
        val btnCalendar = findViewById<ImageButton>(R.id.btnCalendar)
        val btnSettings = findViewById<ImageButton>(R.id.btnSettings)
        val btnList = findViewById<ImageButton>(R.id.btnList)
        val btnAddAlarm = findViewById<Button>(R.id.btnAddAlarm) // Кнопка для добавления будильника

        // Переход на экран будильников
        btnAlarm.setOnClickListener {
            val intent = Intent(this, AlarmActivity::class.java)
            startActivity(intent)
        }

        // Переход на календарь
        btnCalendar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Кнопка настроек не имеет действия, как указано
        // btnSettings.setOnClickListener {...} - ничего не делаем

        // Переход на экран списка задач
        btnList.setOnClickListener {
            val intent = Intent(this, GeneralActivity::class.java)
            startActivity(intent)
        }

        // Переход на экран редактирования будильника
        btnAddAlarm.setOnClickListener {
            val intent = Intent(this, EditAlarmActivity::class.java) // Открытие активности для редактирования
            startActivity(intent)
        }
    }
}
