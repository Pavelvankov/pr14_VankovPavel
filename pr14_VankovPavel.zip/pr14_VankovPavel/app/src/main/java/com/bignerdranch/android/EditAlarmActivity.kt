package com.bignerdranch.android.pr14_vankovpavel

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class EditAlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_alarm)

        // Кнопка назад
        val backButton = findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            onBackPressed()  // Возвращаемся назад
        }

        // Кнопка "Сохранить будильник"
        val btnSaveAlarm = findViewById<Button>(R.id.btnSaveAlarm)
        btnSaveAlarm.setOnClickListener {
            // Переход на GeneralActivity (сохраняем изменения)
            val intent = Intent(this, GeneralActivity::class.java)
            startActivity(intent)
        }

        // Кнопка "Удалить будильник"
        val btnDeleteAlarm = findViewById<Button>(R.id.btnDeleteAlarm)
        btnDeleteAlarm.setOnClickListener {
            // Переход на GeneralActivity (удаляем будильник)
            val intent = Intent(this, GeneralActivity::class.java)
            startActivity(intent)
        }
    }
}
